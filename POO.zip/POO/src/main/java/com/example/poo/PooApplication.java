package com.example.poo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooApplication {

    public static void main(String[] args) {
        SpringApplication.run(PooApplication.class, args);
    }

}
